Please add textfield for "Contact Person" in the reservation module.

	 